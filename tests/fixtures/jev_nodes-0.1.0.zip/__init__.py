"""Jev Nodes: ask a local decision model from Geometry Nodes.

Two nodes: Ask Jev (a question in, a number out) and Jev Pick (a prompt and a list in, one item
out). The model runs on this computer: SemIf's open "System One" method on Qwen3.5-4B, served
by a small Jev-compatible server in its own Python environment.
"""

bl_info = {  # legacy add-on installs (the extension manifest is used on Blender 4.2+)
    "name": "Jev Nodes",
    "author": "Nic",
    "version": (0, 1, 0),
    "blender": (4, 2, 0),
    "location": "Geometry Node Editor > Add > Jev, Sidebar > Jev",
    "description": "Ask a local decision model from Geometry Nodes",
    "category": "Node",
}

import bpy

from . import engine, nodes, ops, prefs, server, ui

_modules = (ops, nodes, ui)


def register():
    bpy.utils.register_class(prefs.JevPreferences)
    for module in _modules:
        module.register()
    engine.register()
    server.refresh()


def unregister():
    engine.unregister()
    server.shutdown_owned()
    for module in reversed(_modules):
        module.unregister()
    bpy.utils.unregister_class(prefs.JevPreferences)
